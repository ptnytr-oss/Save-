package com.hisabkhata.bangla

import android.app.*
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.content.ContentValues
import java.text.SimpleDateFormat
import java.util.*

class DBHelper(c: android.content.Context) : SQLiteOpenHelper(c, "hisab.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT DEFAULT '')")
        db.execSQL("CREATE TABLE entries(id INTEGER PRIMARY KEY AUTOINCREMENT, customer_id INTEGER, kind TEXT NOT NULL, amount REAL NOT NULL, note TEXT DEFAULT '', created_at TEXT NOT NULL, FOREIGN KEY(customer_id) REFERENCES customers(id))")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun customer(name:String, phone:String): Long {
        val db=writableDatabase
        val c=db.rawQuery("SELECT id FROM customers WHERE name=? COLLATE NOCASE AND phone=?", arrayOf(name.trim(),phone.trim()))
        if(c.moveToFirst()){ val id=c.getLong(0); c.close(); return id }; c.close()
        val v=ContentValues().apply { put("name",name.trim()); put("phone",phone.trim()) }
        return db.insert("customers",null,v)
    }
    fun add(customer:Long, kind:String, amount:Double, note:String="") {
        val v=ContentValues().apply { put("customer_id",if(customer>0) customer else null); put("kind",kind); put("amount",amount); put("note",note); put("created_at",now()) }
        writableDatabase.insert("entries",null,v)
    }
    fun now()=SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(Date())
    fun total(kind:String, period:String="") : Double {
        val where=if(period.isEmpty()) "kind=?" else "kind=? AND created_at LIKE ?"
        val args=if(period.isEmpty()) arrayOf(kind) else arrayOf(kind,"$period%")
        val c=readableDatabase.rawQuery("SELECT COALESCE(SUM(amount),0) FROM entries WHERE $where",args)
        c.moveToFirst(); val n=c.getDouble(0); c.close(); return n
    }
    fun due(customer:Long):Double {
        val c=readableDatabase.rawQuery("SELECT COALESCE(SUM(CASE WHEN kind='বাকি' THEN amount WHEN kind='আদায়' THEN -amount ELSE 0 END),0) FROM entries WHERE customer_id=?", arrayOf(customer.toString()))
        c.moveToFirst(); val n=c.getDouble(0); c.close(); return n
    }
    fun search(q:String):List<String> {
        val out= mutableListOf<String>()
        val c=readableDatabase.rawQuery("SELECT id,name,phone FROM customers WHERE name LIKE ? OR phone LIKE ? ORDER BY name",arrayOf("%$q%","%$q%"))
        while(c.moveToNext()) { val id=c.getLong(0); out.add("$id|${c.getString(1)}|${c.getString(2)}|${due(id)}") }; c.close(); return out
    }
    fun history(id:Long):List<String> {
        val out= mutableListOf<String>()
        val c=readableDatabase.rawQuery("SELECT kind,amount,note,created_at FROM entries WHERE customer_id=? ORDER BY id DESC",arrayOf(id.toString()))
        while(c.moveToNext()) out.add("${c.getString(3)} • ${c.getString(0)} ৳${fmt(c.getDouble(1))}${if(c.getString(2).isNullOrBlank()) "" else " — "+c.getString(2)}")
        c.close(); return out
    }
    fun allEntries(period:String=""):List<String> {
        val out= mutableListOf<String>()
        val sql="SELECT e.kind,e.amount,e.note,e.created_at,COALESCE(c.name,'সাধারণ বিক্রি') FROM entries e LEFT JOIN customers c ON c.id=e.customer_id "+if(period.isEmpty()) "" else "WHERE e.created_at LIKE '$period%' "+"ORDER BY e.id DESC"
        val c=readableDatabase.rawQuery(sql,null)
        while(c.moveToNext()) out.add("${c.getString(3)} • ${c.getString(4)} • ${c.getString(0)} ৳${fmt(c.getDouble(1))}${if(c.getString(2).isNullOrBlank()) "" else " — "+c.getString(2)}")
        c.close(); return out
    }
    fun customersAll():List<String> {
        val out= mutableListOf<String>()
        val c=readableDatabase.rawQuery("SELECT id,name,phone FROM customers ORDER BY name",null)
        while(c.moveToNext()) out.add("${c.getLong(0)}|${c.getString(1)}|${c.getString(2)}|${due(c.getLong(0))}")
        c.close(); return out
    }
}
fun fmt(n:Double)=String.format(Locale("bn","BD"),"%.2f",n).removeSuffix(".00")

class MainActivity : Activity() {
    private lateinit var db:DBHelper
    private lateinit var body:LinearLayout
    private val green=0xFF087F5B.toInt()
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState); db=DBHelper(this); home()}
    private fun base(title:String) {
        val outer=LinearLayout(this).apply { orientation=1; setPadding(20,18,20,16); setBackgroundColor(0xFFF5F7F6.toInt()) }
        val head=TextView(this).apply { text=title; textSize=24f; setTextColor(green); typeface=Typeface.DEFAULT_BOLD; setPadding(0,8,0,18) }; outer.addView(head)
        val scroll=ScrollView(this); body=LinearLayout(this).apply { orientation=1 }; scroll.addView(body); outer.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        val nav=LinearLayout(this).apply { orientation=0; gravity=Gravity.CENTER; setPadding(0,10,0,0) }
        listOf("হোম","বিক্রি","বাকি যোগ","আদায়","খাতা").forEachIndexed { i,s -> val b=Button(this).apply { text=s; textSize=11f; setOnClickListener { when(i){0->home();1->sale();2->debt();3->payment();else->ledger()} } }; nav.addView(b,LinearLayout.LayoutParams(0,-2,1f)) }
        outer.addView(nav); setContentView(outer)
    }
    private fun label(t:String){ body.addView(TextView(this).apply { text=t; textSize=16f; setTextColor(0xFF26332E.toInt()); setPadding(0,8,0,8) }) }
    private fun field(hint:String):EditText { val e=EditText(this).apply { this.hint=hint; textSize=16f; singleLine=true }; body.addView(e); return e }
    private fun btn(t:String, action:()->Unit){ body.addView(Button(this).apply { text=t; setOnClickListener { action() } }) }
    private fun msg(t:String){ Toast.makeText(this,t,Toast.LENGTH_LONG).show() }
    private fun home(){
        base("বাংলা হিসাব খাতা")
        label("সহজে রাখুন বিক্রি, বাকি ও আদায়ের হিসাব")
        val today=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())
        label("আজকের মোট বিক্রি: ৳${fmt(db.total("বিক্রি",today))}")
        label("আজকের নগদ আদায়: ৳${fmt(db.total("আদায়",today))}")
        label("আজ নতুন বাকি: ৳${fmt(db.total("বাকি",today))}")
        label("সর্বমোট বাকি (সব ক্রেতা): ৳${fmt(db.total("বাকি")-db.total("আদায়"))}")
        label("দ্রুত কাজ")
        btn("নতুন বিক্রি যোগ করুন"){sale()}
        btn("ক্রেতার বাকি যোগ করুন"){debt()}
        btn("টাকা আদায় করুন"){payment()}
        btn("দৈনিক / মাসিক রিপোর্ট"){reports()}
        btn("অনলাইন ব্যাকআপ সেটআপ নির্দেশনা"){cloudInfo()}
    }
    private fun sale(){
        base("নতুন বিক্রি")
        val amount=field("বিক্রির পরিমাণ (টাকা)")
        val note=field("বিবরণ (ঐচ্ছিক)")
        btn("বিক্রি সেভ করুন"){ val n=amount.text.toString().toDoubleOrNull(); if(n==null||n<=0) msg("সঠিক টাকার পরিমাণ লিখুন") else { db.add(-1,"বিক্রি",n,note.text.toString()); msg("বিক্রি সেভ হয়েছে"); home() } }
    }
    private fun customerFields():Pair<EditText,EditText>{
        label("ক্রেতার তথ্য"); val name=field("ক্রেতার নাম"); val phone=field("মোবাইল নম্বর"); return Pair(name,phone)
    }
    private fun debt(){
        base("বাকি যোগ করুন"); val (name,phone)=customerFields()
        val amount=field("বাকির পরিমাণ (টাকা)"); val note=field("পণ্য / বিবরণ")
        btn("বাকি সেভ করুন"){ val n=amount.text.toString().toDoubleOrNull(); if(name.text.isBlank()||n==null||n<=0) msg("নাম ও সঠিক টাকার পরিমাণ দিন") else { val id=db.customer(name.text.toString(),phone.text.toString()); db.add(id,"বাকি",n,note.text.toString()); msg("বাকি সেভ হয়েছে"); home() } }
    }
    private fun payment(){
        base("টাকা আদায়"); val query=field("ক্রেতার নাম বা মোবাইল সার্চ করুন")
        val results=LinearLayout(this).apply { orientation=1 }; body.addView(results)
        var selected:Long=-1
        query.addTextChangedListener(SimpleWatcher { q ->
            results.removeAllViews()
            db.search(q).forEach { row -> val p=row.split("|"); val id=p[0].toLong(); results.addView(Button(this).apply { text="${p[1]} • বাকি ৳${fmt(p[3].toDoubleOrNull()?:0.0)}"; setOnClickListener { selected=id; query.setText(p[1]); query.setSelection(query.text.length) } }) }
        })
        val amount=field("যত টাকা জমা দিলেন")
        val note=field("নোট (ঐচ্ছিক)")
        btn("আদায় সেভ করুন"){ val n=amount.text.toString().toDoubleOrNull(); if(selected<0||n==null||n<=0) msg("আগে তালিকা থেকে ক্রেতা বাছাই করুন এবং টাকা লিখুন") else { db.add(selected,"আদায়",n,note.text.toString()); msg("আদায় সেভ হয়েছে"); home() } }
    }
    private fun ledger(){
        base("বাকি খাতা")
        val q=field("নাম / ফোন দিয়ে সার্চ")
        val results=LinearLayout(this).apply { orientation=1 }; body.addView(results)
        fun render(query:String){ results.removeAllViews(); db.search(query).forEach { row -> val p=row.split("|"); val id=p[0].toLong(); results.addView(Button(this).apply { text="${p[1]} (${p[2]}) — বাকি ৳${fmt(p[3].toDoubleOrNull()?:0.0)}"; setOnClickListener { customerHistory(id,p[1]) } }) } }
        render(""); q.addTextChangedListener(SimpleWatcher { render(it) })
        label("সাম্প্রতিক লেনদেন")
        db.allEntries().take(30).forEach { label(it) }
    }
    private fun customerHistory(id:Long,name:String){
        base("ক্রেতা: $name")
        label("বর্তমান বাকি: ৳${fmt(db.due(id))}")
        db.history(id).forEach { label(it) }
        btn("নতুন বাকি যোগ"){debt()}
        btn("টাকা আদায়"){payment()}
    }
    private fun reports(){
        base("দৈনিক ও মাসিক রিপোর্ট")
        val day=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())
        val month=SimpleDateFormat("yyyy-MM",Locale.US).format(Date())
        label("আজ ($day)")
        listOf("বিক্রি","বাকি","আদায়").forEach { label("$it: ৳${fmt(db.total(it,day))}") }
        label("এই মাস ($month)")
        listOf("বিক্রি","বাকি","আদায়").forEach { label("$it: ৳${fmt(db.total(it,month))}") }
        label("সাম্প্রতিক হিসাব")
        db.allEntries().take(100).forEach { label(it) }
    }
    private fun cloudInfo(){
        base("অনলাইন ব্যাকআপ")
        label("এই সংস্করণে সব হিসাব ফোনে অফলাইনে সেভ হয়। অনলাইন ব্যাকআপ চালু করতে Firebase প্রজেক্ট ও google-services.json কনফিগারেশন যোগ করে নিরাপদ সাইন-ইন এবং Firestore sync বাস্তবায়ন করতে হবে।")
        label("সতর্কতা: অনলাইন ব্যাকআপ কনফিগার না করা পর্যন্ত অ্যাপের ডেটা শুধু এই ফোনে থাকবে। অ্যাপ আনইনস্টল বা ফোন নষ্ট হলে ডেটা হারাতে পারেন।")
    }
}
private class SimpleWatcher(val onChange:(String)->Unit): android.text.TextWatcher {
    override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){}
    override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){onChange(s?.toString() ?: "")}
    override fun afterTextChanged(s:android.text.Editable?){}
}
